class BankAccount:
    accounts = []
    def __init__(self, int_rate, balance):
        self.int_rate = int_rate
        self.balance = balance
        BankAccount.accounts.append(self)

    def deposit(self, amount):
        self.balance += amount
        return self

    def withdraw(self, amount):
        if self.balance - amount > 0:
            self.balance -= amount
        else:
            print('Insufficient Funds: Charging a $5 Fee.')
            self.balance -= 5
        return self

    def display_account_info(self):
        print(f"Balance: ${self.balance}")
        return self

    def yield_intrest(self):
        if self.balance > 0:
            self.balance += (self.balance * self.int_rate)
        return self


class User:
    def __init__(self,name):
        self.name = name
        self.account =BankAccount(0.03, 1200)

    def make_deposit(self,amount):
        self.account.deposit(amount)
        return self

    def make_withdrawal(self,amount):
        self.account.withdraw(amount)
        return self

    def display_user_balance(self):
        print(f"User: {self.name}, student Balance: {self.account.display_account_info()}")
        return self

amir = User('Amir')
amir.display_user_balance()
amir.make_deposit(400)
amir.display_user_balance()
amir.make_withdrawal(200)
amir.display_user_balance()
